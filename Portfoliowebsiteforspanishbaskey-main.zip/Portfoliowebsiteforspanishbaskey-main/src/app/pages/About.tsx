import { Link } from "react-router";
import { motion } from "motion/react";
import {
  Award,
  Brain,
  Users,
  Rocket,
  CheckCircle2,
  ArrowRight,
  Target,
} from "lucide-react";

const PROFILE_PHOTO = "https://i.postimg.cc/XN8hgyC0/unnamed-removebg-preview.png";

const skills = [
  { label: "Facebook / Meta Ads", level: 97, color: "#3B82F6" },
  { label: "TikTok Ads", level: 92, color: "#EC4899" },
  { label: "Creative Strategy", level: 88, color: "#F97316" },
  { label: "Conversion Rate Optimization", level: 85, color: "#10B981" },
  { label: "Analytics & Reporting", level: 93, color: "#8B5CF6" },
  { label: "E-commerce Growth", level: 90, color: "#10B981" },
];

const certifications = [
  { name: "Meta Blueprint Certified", org: "Meta / Facebook", icon: "🎓" },
  { name: "TikTok Ads For Business", org: "TikTok Business Center", icon: "🏆" },
  { name: "Google Analytics 4", org: "Google", icon: "📊" },
  { name: "E-commerce Growth Specialist", org: "HubSpot Academy", icon: "🚀" },
];

const values = [
  {
    icon: <Brain size={22} />,
    title: "Data-First Thinking",
    desc: "Every decision is rooted in numbers — not gut feelings. I let the data lead and follow where it goes.",
    color: "#8B5CF6",
  },
  {
    icon: <Target size={22} />,
    title: "Precision Targeting",
    desc: "I build detailed audience maps to find your perfect buyers and eliminate wasted spend.",
    color: "#3B82F6",
  },
  {
    icon: <Rocket size={22} />,
    title: "Growth Partnership",
    desc: "I treat your business like my own — fully invested in your success, not just campaign delivery.",
    color: "#F97316",
  },
  {
    icon: <Users size={22} />,
    title: "Client Transparency",
    desc: "No black boxes. You get full visibility into every metric, spend, and strategic decision.",
    color: "#10B981",
  },
];

export function About() {
  return (
    <div style={{ backgroundColor: "#0A0F1E" }}>
      {/* Hero */}
      <section
        className="pt-28 pb-16 relative overflow-hidden"
        style={{ background: "radial-gradient(ellipse 80% 50% at 50% -10%, rgba(16,185,129,0.10) 0%, transparent 60%), #0A0F1E" }}
      >
        <div
          className="absolute inset-0 opacity-15"
          style={{
            backgroundImage: "linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)",
            backgroundSize: "60px 60px",
          }}
        />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-12">
            <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#10B981" }}>About Me</span>
            <h1
              className="mt-3 text-4xl sm:text-5xl lg:text-6xl"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}
            >
              Meet Spanish Baskey
            </h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Photo */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7 }}
              className="flex justify-center"
            >
              <div className="relative">
                <div
                  className="absolute inset-0 rounded-3xl blur-3xl"
                  style={{ background: "radial-gradient(circle, rgba(16,185,129,0.2) 0%, transparent 70%)", transform: "scale(1.3)" }}
                />
                <div
                  className="relative rounded-3xl overflow-hidden"
                  style={{
                    background: "linear-gradient(135deg, rgba(16,185,129,0.12), rgba(59,130,246,0.08))",
                    border: "1px solid rgba(16,185,129,0.2)",
                    padding: "4px",
                  }}
                >
                  <div
                    className="rounded-3xl overflow-hidden flex items-end justify-center"
                    style={{ backgroundColor: "rgba(13,27,62,0.9)", width: 360, height: 420 }}
                  >
                    <img
                      src={PROFILE_PHOTO}
                      alt="Spanish Baskey"
                      className="w-full h-full object-contain object-bottom"
                    />
                  </div>
                </div>

                {/* Badges */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="absolute -bottom-4 -right-4 rounded-2xl px-5 py-3"
                  style={{
                    backgroundColor: "rgba(10,15,30,0.95)",
                    border: "1px solid rgba(16,185,129,0.25)",
                    backdropFilter: "blur(12px)",
                  }}
                >
                  <div className="flex items-center gap-2">
                    <Award size={18} style={{ color: "#10B981" }} />
                    <div>
                      <div className="text-xs font-bold text-white">Meta Blueprint</div>
                      <div className="text-xs text-gray-400">Certified</div>
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>

            {/* Bio */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
            >
              <h2
                className="text-2xl sm:text-3xl mb-5"
                style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, color: "#fff" }}
              >
                Your Strategic Growth Partner in Paid Media
              </h2>

              <div className="space-y-4 text-gray-300 text-sm leading-relaxed">
                <p>
                  Hi, I'm <strong className="text-white">Spanish Baskey</strong> — a Performance Marketing Specialist with over 6 years of hands-on experience transforming advertising budgets into scalable, profitable growth for e-commerce brands, startups, and SMBs.
                </p>
                <p>
                  I'm obsessed with the intersection of <strong className="text-green-400">consumer psychology</strong>, <strong className="text-green-400">data analytics</strong>, and <strong className="text-green-400">creative storytelling</strong>. I believe that great advertising isn't just about spending money — it's about understanding people deeply enough to show them exactly what they need, at exactly the right moment.
                </p>
                <p>
                  My expertise spans the full paid social funnel: from cold audience discovery on <strong className="text-white">Facebook & Instagram</strong> to viral user acquisition on <strong className="text-pink-400">TikTok</strong>, with meticulous attention to data at every stage. I don't just run ads — I build systems that compound in performance over time.
                </p>
                <p>
                  I work exclusively as a <strong className="text-orange-400">strategic partner</strong>, not just a service vendor. Your business goals become my mission, and I stay accountable to the metrics that matter most to your bottom line.
                </p>
              </div>

              <div className="mt-6 flex flex-wrap gap-3">
                {["6+ Years Experience", "Meta Blueprint Certified", "TikTok Ads Certified", "50+ Brands Scaled"].map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1.5 rounded-full text-xs font-medium"
                    style={{ backgroundColor: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)", color: "#10B981" }}
                  >
                    {tag}
                  </span>
                ))}
              </div>

              <Link
                to="/contact"
                className="inline-flex items-center gap-2 mt-8 px-6 py-3 rounded-xl font-semibold text-sm transition-all duration-200 hover:scale-105"
                style={{
                  background: "linear-gradient(135deg, #10B981, #059669)",
                  color: "#fff",
                  boxShadow: "0 6px 20px rgba(16,185,129,0.35)",
                }}
              >
                Work With Me
                <ArrowRight size={15} />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Skills */}
      <section className="py-20" style={{ backgroundColor: "#050C18" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#10B981" }}>Expertise</span>
            <h2
              className="mt-3 text-3xl sm:text-4xl"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}
            >
              Core Competencies
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
            {skills.map((skill, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-300 font-medium">{skill.label}</span>
                  <span className="text-sm font-bold" style={{ color: skill.color }}>{skill.level}%</span>
                </div>
                <div className="h-2 rounded-full" style={{ backgroundColor: "rgba(255,255,255,0.06)" }}>
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${skill.level}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1, delay: i * 0.1, ease: "easeOut" }}
                    className="h-full rounded-full"
                    style={{ background: `linear-gradient(90deg, ${skill.color}, ${skill.color}aa)` }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20" style={{ backgroundColor: "#0A0F1E" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#F97316" }}>What Drives Me</span>
            <h2
              className="mt-3 text-3xl sm:text-4xl"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}
            >
              My Core Values
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((v, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="rounded-2xl p-6 hover:-translate-y-1 transition-all duration-300"
                style={{ backgroundColor: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
              >
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center mb-4"
                  style={{ backgroundColor: `${v.color}18`, color: v.color }}
                >
                  {v.icon}
                </div>
                <h3 className="mb-2" style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, color: "#fff", fontSize: "1rem" }}>
                  {v.title}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed">{v.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="py-20" style={{ backgroundColor: "#050C18" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#10B981" }}>Credentials</span>
            <h2
              className="mt-3 text-3xl sm:text-4xl"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}
            >
              Certifications & Training
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 max-w-4xl mx-auto">
            {certifications.map((cert, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="rounded-2xl p-5 text-center hover:-translate-y-1 transition-all duration-300"
                style={{
                  backgroundColor: "rgba(255,255,255,0.03)",
                  border: "1px solid rgba(255,255,255,0.08)",
                }}
              >
                <div className="text-3xl mb-3">{cert.icon}</div>
                <h4 className="text-sm font-semibold text-white mb-1">{cert.name}</h4>
                <p className="text-xs text-gray-500">{cert.org}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20" style={{ backgroundColor: "#0A0F1E" }}>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="rounded-3xl p-10"
            style={{
              background: "linear-gradient(135deg, rgba(16,185,129,0.08), rgba(249,115,22,0.05))",
              border: "1px solid rgba(16,185,129,0.15)",
            }}
          >
            <h2
              className="text-3xl mb-4"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff" }}
            >
              Let's Build Something Together
            </h2>
            <p className="text-gray-400 mb-8 text-sm leading-relaxed">
              Ready to take your advertising to the next level? Let's start with a free ad account audit and map out your path to scalable growth.
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl font-semibold text-sm transition-all duration-200 hover:scale-105"
              style={{
                background: "linear-gradient(135deg, #10B981, #059669)",
                color: "#fff",
                boxShadow: "0 6px 20px rgba(16,185,129,0.35)",
              }}
            >
              Start the Conversation
              <ArrowRight size={15} />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}