import { Link } from "react-router";
import { motion } from "motion/react";
import {
  Target,
  TrendingUp,
  Palette,
  BarChart3,
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Play,
  Star,
} from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

const PROFILE_PHOTO = "https://i.postimg.cc/XN8hgyC0/unnamed-removebg-preview.png";

const services = [
  {
    icon: <Target size={26} />,
    title: "Facebook Ads Expert",
    desc: "Full-funnel campaign management with laser-precise audience targeting, dynamic retargeting flows, and ROAS-focused optimization across every stage of your funnel.",
    color: "#3B82F6",
    gradient: "linear-gradient(135deg, rgba(59,130,246,0.15), rgba(59,130,246,0.05))",
  },
  {
    icon: <TrendingUp size={26} />,
    title: "TikTok Ads Strategy",
    desc: "Viral-first creative strategy leveraging platform trends, user-generated content frameworks, and algorithm-driven user acquisition at scalable budgets.",
    color: "#EC4899",
    gradient: "linear-gradient(135deg, rgba(236,72,153,0.15), rgba(236,72,153,0.05))",
  },
  {
    icon: <Palette size={26} />,
    title: "Ad Creative Strategy",
    desc: "End-to-end creative ideation for high-converting visual assets — from hooks to CTAs — engineered to stop scrollers and drive measurable action.",
    color: "#F97316",
    gradient: "linear-gradient(135deg, rgba(249,115,22,0.15), rgba(249,115,22,0.05))",
  },
  {
    icon: <BarChart3 size={26} />,
    title: "Performance Reporting",
    desc: "Crystal-clear, data-driven reporting dashboards that track every dollar spent. Transparent KPIs, actionable insights, and weekly performance reviews.",
    color: "#10B981",
    gradient: "linear-gradient(135deg, rgba(16,185,129,0.15), rgba(16,185,129,0.05))",
  },
];

const stats = [
  { value: "4x–8x", label: "Average ROAS Delivered" },
  { value: "$2M+", label: "Ad Spend Managed" },
  { value: "30%", label: "Avg. CPA Reduction" },
  { value: "50+", label: "Brands Scaled" },
];

const highlights = [
  "Meta Blueprint Certified",
  "TikTok Ads For Business Certified",
  "6+ Years of Paid Media Experience",
  "Specialized in E-commerce & DTC Brands",
];

export function Home() {
  return (
    <div style={{ backgroundColor: "#0A0F1E" }}>
      {/* Hero Section */}
      <section
        className="relative min-h-screen flex items-center overflow-hidden pt-20"
        style={{
          background: "radial-gradient(ellipse 80% 60% at 50% -10%, rgba(16,185,129,0.12) 0%, transparent 60%), #0A0F1E",
        }}
      >
        {/* Background grid */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)",
            backgroundSize: "60px 60px",
          }}
        />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Text Content */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: "easeOut" }}
            >
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full mb-6"
                style={{ backgroundColor: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.25)" }}>
                <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="text-xs font-medium text-green-400">Available for New Projects</span>
              </div>

              <h1
                className="text-4xl sm:text-5xl lg:text-6xl mb-6"
                style={{
                  fontFamily: "'Syne', sans-serif",
                  fontWeight: 800,
                  lineHeight: 1.1,
                  letterSpacing: "-0.02em",
                  color: "#fff",
                }}
              >
                Scaling Brands with{" "}
                <span
                  style={{
                    background: "linear-gradient(135deg, #10B981, #34D399)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                  }}
                >
                  Facebook
                </span>{" "}
                &{" "}
                <span
                  style={{
                    background: "linear-gradient(135deg, #EC4899, #F97316)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                  }}
                >
                  TikTok Ads
                </span>
              </h1>

              <p
                className="text-lg mb-3"
                style={{ fontFamily: "'Syne', sans-serif", fontWeight: 600, color: "#94A3B8" }}
              >
                Data-Driven Advertising by{" "}
                <span style={{ color: "#10B981" }}>Spanish Baskey</span>
              </p>

              <p className="text-gray-400 text-base leading-relaxed mb-8 max-w-xl">
                Generating real ROI and scalable growth for e-commerce brands & startups. I turn ad spend into revenue through precision targeting, creative excellence, and relentless data optimization.
              </p>

              {/* Highlights */}
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-8">
                {highlights.map((h) => (
                  <li key={h} className="flex items-center gap-2 text-sm text-gray-300">
                    <CheckCircle2 size={15} style={{ color: "#10B981", flexShrink: 0 }} />
                    {h}
                  </li>
                ))}
              </ul>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-semibold text-sm transition-all duration-200 hover:scale-105 active:scale-95"
                  style={{
                    background: "linear-gradient(135deg, #10B981, #059669)",
                    color: "#fff",
                    boxShadow: "0 8px 25px rgba(16,185,129,0.4)",
                  }}
                >
                  Let's Discuss Your Growth Strategy
                  <ArrowRight size={16} />
                </Link>
                <Link
                  to="/portfolio"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-semibold text-sm transition-all duration-200 hover:text-green-400"
                  style={{
                    backgroundColor: "rgba(255,255,255,0.05)",
                    border: "1px solid rgba(255,255,255,0.12)",
                    color: "#fff",
                  }}
                >
                  <Play size={14} fill="currentColor" />
                  View Case Studies
                </Link>
              </div>
            </motion.div>

            {/* Profile Photo */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
              className="flex justify-center lg:justify-end"
            >
              <div className="relative">
                {/* Glow */}
                <div
                  className="absolute inset-0 rounded-3xl blur-3xl"
                  style={{ background: "radial-gradient(circle, rgba(16,185,129,0.25) 0%, transparent 70%)", transform: "scale(1.2)" }}
                />
                {/* Card */}
                <div
                  className="relative rounded-3xl overflow-hidden"
                  style={{
                    background: "linear-gradient(135deg, rgba(16,185,129,0.1), rgba(59,130,246,0.08))",
                    border: "1px solid rgba(16,185,129,0.2)",
                    padding: "4px",
                  }}
                >
                  <div
                    className="rounded-3xl overflow-hidden"
                    style={{ backgroundColor: "rgba(13,27,62,0.8)", width: 340, height: 400 }}
                  >
                    <img
                      src={PROFILE_PHOTO}
                      alt="Spanish Baskey - Performance Marketing Specialist"
                      className="w-full h-full object-contain object-bottom"
                    />
                  </div>
                </div>

                {/* Floating stat cards */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6, duration: 0.5 }}
                  className="absolute -left-4 top-12 rounded-2xl px-4 py-3"
                  style={{
                    backgroundColor: "rgba(10,15,30,0.95)",
                    border: "1px solid rgba(16,185,129,0.25)",
                    backdropFilter: "blur(12px)",
                    boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
                  }}
                >
                  <div className="text-xl font-bold text-green-400" style={{ fontFamily: "'Syne', sans-serif" }}>4x–8x</div>
                  <div className="text-xs text-gray-400">Average ROAS</div>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.8, duration: 0.5 }}
                  className="absolute -right-4 bottom-16 rounded-2xl px-4 py-3"
                  style={{
                    backgroundColor: "rgba(10,15,30,0.95)",
                    border: "1px solid rgba(249,115,22,0.25)",
                    backdropFilter: "blur(12px)",
                    boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
                  }}
                >
                  <div className="text-xl font-bold" style={{ color: "#F97316", fontFamily: "'Syne', sans-serif" }}>$2M+</div>
                  <div className="text-xs text-gray-400">Ad Spend Managed</div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Bottom gradient */}
        <div className="absolute bottom-0 left-0 right-0 h-32" style={{ background: "linear-gradient(transparent, #0A0F1E)" }} />
      </section>

      {/* Stats Bar */}
      <section style={{ backgroundColor: "#0D1B3E", borderTop: "1px solid rgba(255,255,255,0.06)", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <div
                  className="text-3xl sm:text-4xl mb-1"
                  style={{
                    fontFamily: "'Syne', sans-serif",
                    fontWeight: 800,
                    background: "linear-gradient(135deg, #10B981, #34D399)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                  }}
                >
                  {stat.value}
                </div>
                <div className="text-xs text-gray-400 font-medium">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 lg:py-28" style={{ backgroundColor: "#0A0F1E" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-14"
          >
            <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#10B981" }}>What I Do</span>
            <h2
              className="mt-3 text-3xl sm:text-4xl lg:text-5xl"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}
            >
              Performance Marketing Services
            </h2>
            <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
              Comprehensive paid advertising solutions designed to generate measurable ROI and sustainable growth.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {services.map((service, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="rounded-2xl p-6 group hover:-translate-y-1 transition-all duration-300"
                style={{
                  background: service.gradient,
                  border: `1px solid ${service.color}22`,
                }}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-5"
                  style={{ backgroundColor: `${service.color}20`, color: service.color }}
                >
                  {service.icon}
                </div>
                <h3
                  className="text-lg mb-3"
                  style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, color: "#fff" }}
                >
                  {service.title}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed">{service.desc}</p>
                <div className="mt-4 flex items-center gap-1 text-xs font-semibold" style={{ color: service.color }}>
                  Learn More <ChevronRight size={14} />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Who I Work With */}
      <section className="py-20" style={{ backgroundColor: "#050C18" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#F97316" }}>Ideal Clients</span>
            <h2
              className="mt-3 text-3xl sm:text-4xl"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}
            >
              Who I Work With
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "E-commerce Brands",
                desc: "DTC & e-commerce businesses ready to scale their ad spend and maximize ROAS with proven paid social strategies.",
                icon: "🛒",
              },
              {
                title: "Tech Startups",
                desc: "Venture-backed and bootstrapped startups seeking efficient user acquisition and growth without burning their runway.",
                icon: "🚀",
              },
              {
                title: "Small & Medium Businesses",
                desc: "SMBs looking to break through plateaus, compete with larger brands, and generate consistent pipeline from paid ads.",
                icon: "📈",
              },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="rounded-2xl p-6 text-center group hover:-translate-y-1 transition-all duration-300"
                style={{ backgroundColor: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <div className="text-4xl mb-4">{item.icon}</div>
                <h3 className="mb-2" style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, color: "#fff", fontSize: "1.1rem" }}>
                  {item.title}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Preview */}
      <section className="py-20" style={{ backgroundColor: "#0A0F1E" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="rounded-3xl p-8 lg:p-12 text-center"
            style={{
              background: "linear-gradient(135deg, rgba(16,185,129,0.08) 0%, rgba(59,130,246,0.06) 100%)",
              border: "1px solid rgba(16,185,129,0.15)",
            }}
          >
            <div className="flex justify-center gap-1 mb-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} size={18} fill="#F97316" color="#F97316" />
              ))}
            </div>
            <blockquote
              className="text-xl lg:text-2xl text-white mb-5 max-w-3xl mx-auto"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 500, lineHeight: 1.5 }}
            >
              "Spanish Baskey took our ROAS from 1.8x to 6.2x in just 90 days. Our fashion brand went from struggling to cover ad costs to scaling confidently with consistent profitability."
            </blockquote>
            <p className="text-gray-400 text-sm font-medium">— Sarah M., Founder, LuxeThreads Fashion</p>

            <Link
              to="/testimonials"
              className="inline-flex items-center gap-2 mt-8 px-6 py-3 rounded-xl text-sm font-semibold transition-all duration-200 hover:text-green-400"
              style={{
                backgroundColor: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.12)",
                color: "#fff",
              }}
            >
              Read All Testimonials <ArrowRight size={14} />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-28" style={{ backgroundColor: "#050C18" }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2
              className="text-3xl sm:text-4xl lg:text-5xl mb-6"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}
            >
              Ready to Scale Your{" "}
              <span style={{ background: "linear-gradient(135deg, #10B981, #34D399)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Ad Performance?
              </span>
            </h2>
            <p className="text-gray-400 mb-8 text-base leading-relaxed max-w-2xl mx-auto">
              Book a free ad account audit and discover exactly where your campaigns are leaking money — and how to fix it.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/contact"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl font-semibold text-sm transition-all duration-200 hover:scale-105 active:scale-95"
                style={{
                  background: "linear-gradient(135deg, #10B981, #059669)",
                  color: "#fff",
                  boxShadow: "0 8px 25px rgba(16,185,129,0.4)",
                }}
              >
                Get a Free Ad Account Audit
                <ArrowRight size={16} />
              </Link>
              <Link
                to="/process"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl font-semibold text-sm transition-all duration-200 hover:text-white"
                style={{
                  border: "1px solid rgba(255,255,255,0.12)",
                  color: "#9CA3AF",
                }}
              >
                See My Process
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
