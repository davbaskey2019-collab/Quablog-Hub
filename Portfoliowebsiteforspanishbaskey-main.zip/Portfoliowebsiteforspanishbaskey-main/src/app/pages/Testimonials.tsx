import { Link } from "react-router";
import { motion } from "motion/react";
import { Star, Quote, ArrowRight, TrendingUp } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Sarah Mitchell",
    role: "Founder & CEO",
    company: "LuxeThreads Fashion",
    industry: "Fashion E-commerce",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=80&h=80&fit=crop&crop=face",
    rating: 5,
    quote:
      "Spanish Baskey completely transformed our Facebook Ads performance. We went from a 1.8x ROAS to 6.2x in just 90 days. Our revenue almost quintupled without a proportional increase in spend. He's not just a media buyer — he's a true growth strategist.",
    result: "6.2x ROAS in 90 Days",
    resultColor: "#10B981",
    featured: true,
  },
  {
    id: 2,
    name: "Marcus Johnson",
    role: "Head of Growth",
    company: "Nexflow SaaS",
    industry: "B2B SaaS",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&crop=face",
    rating: 5,
    quote:
      "I was skeptical about paid social for B2B SaaS, but Spanish Baskey proved me wrong. He reduced our CPA from $124 to $38, and our trial signups went from 210 to 847 per month. His audience targeting strategy for LinkedIn and Facebook was surgical.",
    result: "69% CPA Reduction",
    resultColor: "#8B5CF6",
    featured: true,
  },
  {
    id: 3,
    name: "Priya Sharma",
    role: "Co-Founder",
    company: "VitalCore Supplements",
    industry: "Health & Wellness",
    avatar: "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=80&h=80&fit=crop&crop=face",
    rating: 5,
    quote:
      "Spanish Baskey built our entire TikTok Ads presence from scratch. Within 12 weeks, we had 4.2 million organic-quality video views, 2,847 conversions, and a 4.1x ROAS. His creative strategy for TikTok is genuinely next-level.",
    result: "4.2M Views + 4.1x ROAS",
    resultColor: "#EC4899",
    featured: true,
  },
  {
    id: 4,
    name: "David Chen",
    role: "Founder",
    company: "TechFlow Startup",
    industry: "Fintech",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop&crop=face",
    rating: 5,
    quote:
      "Working with Spanish Baskey was one of the best investments we made in our startup. He audited our accounts in just 3 days, found we were wasting 40% of our budget, and rebuilt everything from scratch. Month 2 was our best revenue month ever.",
    result: "40% Budget Waste Eliminated",
    resultColor: "#3B82F6",
    featured: false,
  },
  {
    id: 5,
    name: "Emma Rodriguez",
    role: "Marketing Director",
    company: "HomeDecor Plus",
    industry: "Home & Living",
    avatar: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=80&h=80&fit=crop&crop=face",
    rating: 5,
    quote:
      "The weekly reporting alone was worth it. Spanish Baskey gives you total transparency — no hiding behind 'algorithm changes'. He explains exactly what's happening, why, and what he's doing about it. Results were incredible: 200% increase in conversions.",
    result: "200% Conversion Increase",
    resultColor: "#F97316",
    featured: false,
  },
  {
    id: 6,
    name: "James Thompson",
    role: "CEO",
    company: "GreenBox Subscription",
    industry: "Subscription E-commerce",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=80&h=80&fit=crop&crop=face",
    rating: 5,
    quote:
      "Spanish Baskey helped us scale our subscription box from 1,200 to 4,800 active subscribers in 5 months using Facebook and TikTok. His understanding of subscription economics and LTV-based bidding strategies is unlike anyone I've worked with.",
    result: "4x Subscriber Growth",
    resultColor: "#10B981",
    featured: false,
  },
];

const platforms = [
  { name: "Meta Ads Manager", logo: "📘" },
  { name: "TikTok Business Center", logo: "🎵" },
  { name: "Google Analytics 4", logo: "📊" },
  { name: "Shopify", logo: "🛍️" },
  { name: "Klaviyo", logo: "📧" },
  { name: "Triple Whale", logo: "🐋" },
];

export function Testimonials() {
  const featured = testimonials.filter((t) => t.featured);
  const rest = testimonials.filter((t) => !t.featured);

  return (
    <div style={{ backgroundColor: "#0A0F1E" }}>
      {/* Header */}
      <section
        className="pt-28 pb-14 relative overflow-hidden"
        style={{ background: "radial-gradient(ellipse 80% 50% at 50% -10%, rgba(249,115,22,0.08) 0%, transparent 60%), #0A0F1E" }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#F97316" }}>Client Success</span>
            <h1
              className="mt-3 text-4xl sm:text-5xl lg:text-6xl"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}
            >
              What Clients Say{" "}
              <span style={{ background: "linear-gradient(135deg, #F97316, #EF4444)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                About Me
              </span>
            </h1>
            <p className="mt-5 text-gray-400 max-w-2xl mx-auto text-base leading-relaxed">
              Don't take my word for it — here's what real clients have experienced working with Spanish Baskey on their paid advertising growth.
            </p>

            {/* Rating summary */}
            <div className="flex items-center justify-center gap-3 mt-8">
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={20} fill="#F97316" color="#F97316" />
                ))}
              </div>
              <span className="text-white font-bold text-xl" style={{ fontFamily: "'Syne', sans-serif" }}>5.0</span>
              <span className="text-gray-400 text-sm">from 50+ clients</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Testimonials */}
      <section className="pb-16" style={{ backgroundColor: "#0A0F1E" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {featured.map((t, i) => (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="rounded-2xl p-6 lg:p-7 relative hover:-translate-y-1 transition-all duration-300"
                style={{
                  background: "linear-gradient(135deg, rgba(255,255,255,0.04), rgba(255,255,255,0.01))",
                  border: "1px solid rgba(255,255,255,0.09)",
                }}
              >
                {/* Quote icon */}
                <div className="absolute top-5 right-5 opacity-20">
                  <Quote size={32} style={{ color: t.resultColor }} />
                </div>

                {/* Stars */}
                <div className="flex items-center gap-0.5 mb-4">
                  {Array.from({ length: t.rating }).map((_, si) => (
                    <Star key={si} size={14} fill="#F97316" color="#F97316" />
                  ))}
                </div>

                {/* Result badge */}
                <div
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold mb-4"
                  style={{ backgroundColor: `${t.resultColor}15`, color: t.resultColor, border: `1px solid ${t.resultColor}25` }}
                >
                  <TrendingUp size={11} />
                  {t.result}
                </div>

                {/* Quote */}
                <blockquote className="text-gray-300 text-sm leading-relaxed mb-6">
                  "{t.quote}"
                </blockquote>

                {/* Client */}
                <div className="flex items-center gap-3">
                  <img
                    src={t.avatar}
                    alt={t.name}
                    className="w-10 h-10 rounded-full object-cover"
                    style={{ border: `2px solid ${t.resultColor}40` }}
                  />
                  <div>
                    <div className="text-sm font-semibold text-white">{t.name}</div>
                    <div className="text-xs text-gray-500">{t.role} · {t.company}</div>
                  </div>
                </div>

                {/* Industry tag */}
                <div
                  className="mt-4 text-xs px-2 py-1 rounded-md inline-block"
                  style={{ backgroundColor: "rgba(255,255,255,0.05)", color: "#9CA3AF" }}
                >
                  {t.industry}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Rest of testimonials */}
      <section className="pb-20" style={{ backgroundColor: "#0A0F1E" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {rest.map((t, i) => (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="rounded-2xl p-6 relative hover:-translate-y-1 transition-all duration-300"
                style={{
                  backgroundColor: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.07)",
                }}
              >
                <div className="flex items-center gap-0.5 mb-3">
                  {Array.from({ length: t.rating }).map((_, si) => (
                    <Star key={si} size={13} fill="#F97316" color="#F97316" />
                  ))}
                </div>

                <div
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold mb-3"
                  style={{ backgroundColor: `${t.resultColor}15`, color: t.resultColor }}
                >
                  <TrendingUp size={10} />
                  {t.result}
                </div>

                <blockquote className="text-gray-400 text-sm leading-relaxed mb-5">
                  "{t.quote}"
                </blockquote>

                <div className="flex items-center gap-3">
                  <img
                    src={t.avatar}
                    alt={t.name}
                    className="w-9 h-9 rounded-full object-cover"
                    style={{ border: `1.5px solid ${t.resultColor}40` }}
                  />
                  <div>
                    <div className="text-sm font-semibold text-white">{t.name}</div>
                    <div className="text-xs text-gray-500">{t.role} · {t.company}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Platforms */}
      <section className="py-16" style={{ backgroundColor: "#050C18" }}>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-8"
          >
            <p className="text-xs font-semibold uppercase tracking-widest text-gray-500">Platforms & Tools I Work With</p>
          </motion.div>

          <div className="flex flex-wrap justify-center gap-4">
            {platforms.map((p, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl"
                style={{ backgroundColor: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <span className="text-lg">{p.logo}</span>
                <span className="text-sm text-gray-300 font-medium">{p.name}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20" style={{ backgroundColor: "#0A0F1E" }}>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="rounded-3xl p-10"
            style={{
              background: "linear-gradient(135deg, rgba(249,115,22,0.08), rgba(239,68,68,0.05))",
              border: "1px solid rgba(249,115,22,0.15)",
            }}
          >
            <div className="flex items-center justify-center gap-1 mb-4">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} size={20} fill="#F97316" color="#F97316" />
              ))}
            </div>
            <h2
              className="text-3xl mb-4"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff" }}
            >
              Join the Success Stories
            </h2>
            <p className="text-gray-400 mb-8 text-sm leading-relaxed">
              Your business deserves the same level of performance, transparency, and growth these clients experienced.
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-xl font-semibold text-sm transition-all duration-200 hover:scale-105"
              style={{
                background: "linear-gradient(135deg, #F97316, #EF4444)",
                color: "#fff",
                boxShadow: "0 8px 25px rgba(249,115,22,0.35)",
              }}
            >
              Start Your Growth Journey
              <ArrowRight size={15} />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}