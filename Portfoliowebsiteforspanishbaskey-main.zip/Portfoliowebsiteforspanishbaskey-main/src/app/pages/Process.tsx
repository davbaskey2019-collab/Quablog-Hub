import { Link } from "react-router";
import { motion } from "motion/react";
import {
  MessageSquare,
  Search,
  Lightbulb,
  Rocket,
  Settings,
  TrendingUp,
  ArrowRight,
  Clock,
  CheckCircle2,
} from "lucide-react";

const steps = [
  {
    number: "01",
    icon: <MessageSquare size={26} />,
    title: "Discovery Call",
    subtitle: "Free 45-Minute Consultation",
    desc: "We start with a no-obligation strategy call to understand your business, goals, current challenges, and what success looks like for you. This is where I learn your story.",
    deliverables: [
      "Business goals alignment",
      "Current performance review",
      "Competitive landscape snapshot",
      "Potential growth levers identified",
    ],
    duration: "45–60 mins",
    color: "#3B82F6",
  },
  {
    number: "02",
    icon: <Search size={26} />,
    title: "Full Account Audit",
    subtitle: "Deep-Dive Analysis",
    desc: "I conduct a comprehensive audit of your existing ad accounts, creatives, landing pages, and funnel — identifying exactly where money is being wasted and where opportunities are hiding.",
    deliverables: [
      "Ad account health score",
      "Creative performance analysis",
      "Audience overlap detection",
      "Funnel conversion breakdown",
    ],
    duration: "3–5 business days",
    color: "#F97316",
  },
  {
    number: "03",
    icon: <Lightbulb size={26} />,
    title: "Strategy Blueprint",
    subtitle: "Custom Growth Roadmap",
    desc: "Based on the audit, I build a bespoke paid media strategy — platform mix, budget allocation, audience architecture, creative direction, and KPI benchmarks — tailored to your specific business.",
    deliverables: [
      "Platform & budget strategy",
      "Audience segmentation plan",
      "Creative brief & direction",
      "90-day KPI projections",
    ],
    duration: "2–3 business days",
    color: "#8B5CF6",
  },
  {
    number: "04",
    icon: <Rocket size={26} />,
    title: "Campaign Launch",
    subtitle: "Precision Execution",
    desc: "With strategy approved, I build and launch your campaigns with surgical precision — setting up pixels, conversion events, audience stacks, and creative assets for immediate performance.",
    deliverables: [
      "Full campaign build & setup",
      "Pixel & conversion tracking",
      "Creative production coordination",
      "Launch day monitoring",
    ],
    duration: "5–7 business days",
    color: "#10B981",
  },
  {
    number: "05",
    icon: <Settings size={26} />,
    title: "Optimize & Manage",
    subtitle: "Daily Hands-On Management",
    desc: "I manage your campaigns daily — testing new creatives, adjusting bids, pruning underperformers, and capitalizing on winning signals. You get weekly performance reports with no fluff.",
    deliverables: [
      "Daily bid & budget optimization",
      "Weekly creative testing",
      "A/B test reporting",
      "Weekly performance reports",
    ],
    duration: "Ongoing",
    color: "#EC4899",
  },
  {
    number: "06",
    icon: <TrendingUp size={26} />,
    title: "Scale & Grow",
    subtitle: "Responsible Revenue Scaling",
    desc: "Once we've found winning campaigns, I implement controlled scaling strategies — increasing budgets, expanding audiences, and launching new creative angles — all while protecting your ROAS.",
    deliverables: [
      "Budget scaling playbook",
      "New audience expansion",
      "International market testing",
      "Quarterly growth reviews",
    ],
    duration: "Ongoing",
    color: "#10B981",
  },
];

export function Process() {
  return (
    <div style={{ backgroundColor: "#0A0F1E" }}>
      {/* Header */}
      <section
        className="pt-28 pb-14 relative overflow-hidden"
        style={{ background: "radial-gradient(ellipse 80% 50% at 50% -10%, rgba(139,92,246,0.10) 0%, transparent 60%), #0A0F1E" }}
      >
        <div
          className="absolute inset-0 opacity-15"
          style={{
            backgroundImage: "linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)",
            backgroundSize: "60px 60px",
          }}
        />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#8B5CF6" }}>How It Works</span>
            <h1
              className="mt-3 text-4xl sm:text-5xl lg:text-6xl"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}
            >
              My Proven{" "}
              <span style={{ background: "linear-gradient(135deg, #8B5CF6, #EC4899)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                6-Step Process
              </span>
            </h1>
            <p className="mt-5 text-gray-400 max-w-2xl mx-auto text-base leading-relaxed">
              A structured, systematic approach to transforming your ad spend into predictable, scalable revenue — from first contact to sustainable growth.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Process Steps */}
      <section className="pb-24" style={{ backgroundColor: "#0A0F1E" }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative">
            {/* Vertical line */}
            <div
              className="absolute left-8 top-0 bottom-0 w-px hidden md:block"
              style={{ background: "linear-gradient(to bottom, rgba(255,255,255,0.0), rgba(255,255,255,0.08) 10%, rgba(255,255,255,0.08) 90%, rgba(255,255,255,0.0))" }}
            />

            <div className="space-y-8">
              {steps.map((step, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08, duration: 0.5 }}
                  className="relative flex gap-6 md:gap-8"
                >
                  {/* Step circle */}
                  <div className="flex-shrink-0 relative z-10">
                    <div
                      className="w-16 h-16 rounded-2xl flex items-center justify-center"
                      style={{
                        background: `linear-gradient(135deg, ${step.color}25, ${step.color}10)`,
                        border: `2px solid ${step.color}40`,
                        color: step.color,
                      }}
                    >
                      {step.icon}
                    </div>
                  </div>

                  {/* Content */}
                  <div
                    className="flex-1 rounded-2xl p-6 lg:p-7 hover:-translate-y-0.5 transition-all duration-300"
                    style={{ backgroundColor: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)" }}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                      <div>
                        <div className="flex items-center gap-3 mb-1">
                          <span
                            className="text-xs font-black"
                            style={{ color: step.color, fontFamily: "'Syne', sans-serif" }}
                          >
                            {step.number}
                          </span>
                          <div
                            className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-full"
                            style={{ backgroundColor: `${step.color}15`, color: step.color }}
                          >
                            <Clock size={10} />
                            {step.duration}
                          </div>
                        </div>
                        <h2
                          className="text-xl"
                          style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, color: "#fff" }}
                        >
                          {step.title}
                        </h2>
                        <p className="text-sm" style={{ color: step.color }}>{step.subtitle}</p>
                      </div>
                    </div>

                    <p className="text-gray-400 text-sm leading-relaxed mb-5">{step.desc}</p>

                    <div>
                      <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Deliverables</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                        {step.deliverables.map((d, di) => (
                          <div key={di} className="flex items-center gap-2 text-sm text-gray-300">
                            <CheckCircle2 size={13} style={{ color: step.color, flexShrink: 0 }} />
                            {d}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Timeline Visual */}
      <section className="py-16" style={{ backgroundColor: "#050C18" }}>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-10"
          >
            <h2
              className="text-2xl sm:text-3xl"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff" }}
            >
              From Kickoff to Scaling — Typical Timeline
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative overflow-x-auto"
          >
            <div className="flex items-stretch gap-0 min-w-max mx-auto">
              {[
                { label: "Week 1", activity: "Audit & Strategy", color: "#3B82F6" },
                { label: "Week 2", activity: "Creative + Setup", color: "#F97316" },
                { label: "Week 3", activity: "Launch & Monitor", color: "#10B981" },
                { label: "Week 4–8", activity: "Optimize & Test", color: "#8B5CF6" },
                { label: "Month 3+", activity: "Scale & Grow", color: "#EC4899" },
              ].map((t, i) => (
                <div key={i} className="flex flex-col items-center">
                  <div
                    className="px-5 py-3 text-center"
                    style={{ minWidth: 140 }}
                  >
                    <div className="text-xs text-gray-500 font-medium mb-1">{t.label}</div>
                    <div
                      className="px-3 py-2 rounded-lg text-xs font-semibold"
                      style={{ backgroundColor: `${t.color}18`, color: t.color, border: `1px solid ${t.color}30` }}
                    >
                      {t.activity}
                    </div>
                  </div>
                  {i < 4 && (
                    <div className="flex items-center" style={{ color: "#374151" }}>
                      <ArrowRight size={16} />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20" style={{ backgroundColor: "#0A0F1E" }}>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2
              className="text-3xl"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff" }}
            >
              Common Questions
            </h2>
          </motion.div>

          <div className="space-y-4">
            {[
              {
                q: "What's the minimum ad spend you work with?",
                a: "I typically work with clients investing a minimum of $3,000/month in ad spend. This ensures we have enough data velocity to optimize and scale effectively.",
              },
              {
                q: "How quickly will I see results?",
                a: "Most clients see early performance signals within the first 2–4 weeks. Significant ROAS improvements typically become consistent between weeks 6–10 as the algorithm learns and creative testing matures.",
              },
              {
                q: "Do you work with both Facebook and TikTok simultaneously?",
                a: "Yes — I specialize in running both platforms together for a full paid social ecosystem. I can also start with one platform and expand to the other once baseline ROI is established.",
              },
              {
                q: "How does reporting work?",
                a: "You receive a detailed weekly performance report every Monday, covering all key KPIs, test results, spend breakdown, and next-week priorities. I'm also available via Slack for quick questions.",
              },
            ].map((faq, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="rounded-xl p-5"
                style={{ backgroundColor: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
              >
                <h4 className="font-semibold text-white mb-2 text-sm" style={{ fontFamily: "'Syne', sans-serif" }}>{faq.q}</h4>
                <p className="text-gray-400 text-sm leading-relaxed">{faq.a}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20" style={{ backgroundColor: "#050C18" }}>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2
              className="text-3xl sm:text-4xl mb-5"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff" }}
            >
              Ready to Start Step 1?
            </h2>
            <p className="text-gray-400 mb-8 text-sm">
              Book your free discovery call today. Zero pressure, zero commitment — just a real conversation about your growth.
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-xl font-semibold text-sm transition-all duration-200 hover:scale-105"
              style={{
                background: "linear-gradient(135deg, #8B5CF6, #EC4899)",
                color: "#fff",
                boxShadow: "0 8px 25px rgba(139,92,246,0.35)",
              }}
            >
              Book Your Free Discovery Call
              <ArrowRight size={15} />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
