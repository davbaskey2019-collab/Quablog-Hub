import { useState } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  Legend,
} from "recharts";
import { TrendingUp, TrendingDown, ArrowRight, ChevronDown, ChevronUp } from "lucide-react";

const cases = [
  {
    id: 0,
    industry: "Fashion Retail (E-commerce)",
    client: "LuxeThreads Fashion",
    platform: "Facebook & Instagram Ads",
    platformColors: ["#3B82F6", "#EC4899"],
    challenge: "Low ROAS of 1.8x with high customer acquisition costs ($62 CPA). Struggling to scale beyond $5K/month ad spend profitably.",
    strategy: [
      "Full funnel restructure — TOFU (broad video reach), MOFU (catalog retargeting), BOFU (dynamic product ads)",
      "Lookalike audiences built from top 5% LTV customers",
      "Creative split testing: 40+ video/static ad variants in 60 days",
      "Implemented post-purchase upsell flows to boost AOV",
    ],
    results: [
      { metric: "ROAS", before: "1.8x", after: "6.2x", change: "+244%", positive: true },
      { metric: "CPA", before: "$62", after: "$31", change: "-50%", positive: true },
      { metric: "Monthly Revenue", before: "$38K", after: "$182K", change: "+379%", positive: true },
      { metric: "Ad Spend", before: "$5K", after: "$29K", change: "+480%", positive: true },
    ],
    chartData: [
      { month: "Jan", roas: 1.8, revenue: 38000 },
      { month: "Feb", roas: 2.4, revenue: 52000 },
      { month: "Mar", roas: 3.1, revenue: 74000 },
      { month: "Apr", roas: 4.2, revenue: 108000 },
      { month: "May", roas: 5.0, revenue: 145000 },
      { month: "Jun", roas: 6.2, revenue: 182000 },
    ],
    chartType: "area",
    accentColor: "#10B981",
    tag: "E-commerce",
  },
  {
    id: 1,
    industry: "SaaS / Tech Startup",
    client: "Nexflow SaaS",
    platform: "Facebook Ads + TikTok Ads",
    platformColors: ["#3B82F6", "#EC4899"],
    challenge: "High CPA of $120+ for trial signups. Poor video creatives not resonating with target B2B audience. Wasted budget on broad targeting.",
    strategy: [
      "Rebuilt audiences using job-title and interest-based targeting stacks",
      "Launched TikTok Ads with 'native feel' UGC-style demo creatives",
      "Implemented 7-day email drip triggered by ad click UTMs",
      "A/B tested landing pages with 8 variants for CRO",
    ],
    results: [
      { metric: "CPA (Trial Signup)", before: "$124", after: "$38", change: "-69%", positive: true },
      { metric: "Trial-to-Paid Rate", before: "11%", after: "27%", change: "+145%", positive: true },
      { metric: "Monthly Signups", before: "210", after: "847", change: "+303%", positive: true },
      { metric: "ROAS", before: "1.4x", after: "4.8x", change: "+243%", positive: true },
    ],
    chartData: [
      { month: "Jan", cpa: 124, signups: 210 },
      { month: "Feb", cpa: 108, signups: 265 },
      { month: "Mar", cpa: 84, signups: 380 },
      { month: "Apr", cpa: 61, signups: 520 },
      { month: "May", cpa: 45, signups: 690 },
      { month: "Jun", cpa: 38, signups: 847 },
    ],
    chartType: "bar",
    accentColor: "#8B5CF6",
    tag: "SaaS",
  },
  {
    id: 2,
    industry: "Health & Wellness (DTC)",
    client: "VitalCore Supplements",
    platform: "TikTok Ads",
    platformColors: ["#EC4899"],
    challenge: "Zero TikTok presence. New to paid social. Needed to drive product sales efficiently against established competitors with massive ad budgets.",
    strategy: [
      "Full TikTok Ads account setup: Spark Ads, TopView, In-Feed Video",
      "Partnered with 12 micro-influencers for native UGC content",
      "Trend-jacking strategy: 3–5 trending audio tracks per week",
      "Conversion pixel optimized for purchase events with 7-day attribution",
    ],
    results: [
      { metric: "ROAS", before: "0x", after: "4.1x", change: "From Zero", positive: true },
      { metric: "Cost Per Purchase", before: "N/A", after: "$18.40", change: "Efficient Launch", positive: true },
      { metric: "Conversions (90 days)", before: "0", after: "2,847", change: "+2847", positive: true },
      { metric: "Video Views", before: "0", after: "4.2M", change: "Viral", positive: true },
    ],
    chartData: [
      { week: "W1", conversions: 28, spend: 500 },
      { week: "W2", conversions: 94, spend: 800 },
      { week: "W3", conversions: 187, spend: 1200 },
      { week: "W4", conversions: 312, spend: 1800 },
      { week: "W8", conversions: 580, spend: 2600 },
      { week: "W12", conversions: 847, spend: 3500 },
    ],
    chartType: "line",
    accentColor: "#EC4899",
    tag: "Health & Wellness",
  },
];

function ResultCard({ metric, before, after, change, positive }: {
  metric: string; before: string; after: string; change: string; positive: boolean;
}) {
  return (
    <div
      className="rounded-xl p-4"
      style={{ backgroundColor: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
    >
      <div className="text-xs text-gray-500 mb-1 font-medium uppercase tracking-wider">{metric}</div>
      <div className="flex items-end justify-between">
        <div>
          <div className="text-xs text-gray-500 mb-0.5">Before: <span className="text-gray-400">{before}</span></div>
          <div className="text-lg font-bold text-white" style={{ fontFamily: "'Syne', sans-serif" }}>{after}</div>
        </div>
        <div
          className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold"
          style={{
            backgroundColor: positive ? "rgba(16,185,129,0.15)" : "rgba(239,68,68,0.15)",
            color: positive ? "#10B981" : "#EF4444",
          }}
        >
          {positive ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
          {change}
        </div>
      </div>
    </div>
  );
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div
        className="rounded-xl p-3"
        style={{ backgroundColor: "#0D1B3E", border: "1px solid rgba(255,255,255,0.1)" }}
      >
        <p className="text-xs text-gray-400 mb-1">{label}</p>
        {payload.map((p: any, i: number) => (
          <p key={i} className="text-sm font-bold" style={{ color: p.color }}>
            {p.name}: {typeof p.value === "number" && p.value > 1000 ? `$${p.value.toLocaleString()}` : p.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export function Portfolio() {
  const [expanded, setExpanded] = useState<number | null>(0);

  return (
    <div style={{ backgroundColor: "#0A0F1E" }}>
      {/* Header */}
      <section
        className="pt-28 pb-14 relative overflow-hidden"
        style={{ background: "radial-gradient(ellipse 80% 50% at 50% -10%, rgba(249,115,22,0.10) 0%, transparent 60%), #0A0F1E" }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#F97316" }}>Proven Results</span>
            <h1
              className="mt-3 text-4xl sm:text-5xl lg:text-6xl"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}
            >
              Case Studies &{" "}
              <span style={{ background: "linear-gradient(135deg, #F97316, #EF4444)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Results
              </span>
            </h1>
            <p className="mt-5 text-gray-400 max-w-2xl mx-auto text-base leading-relaxed">
              Real campaigns. Real data. Real growth. Every case study below represents a brand that trusted me with their ad spend — and saw transformational results.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Case Studies */}
      <section className="pb-20" style={{ backgroundColor: "#0A0F1E" }}>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-8">
            {cases.map((cs, i) => (
              <motion.div
                key={cs.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="rounded-2xl overflow-hidden"
                style={{
                  backgroundColor: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.08)",
                }}
              >
                {/* Header */}
                <button
                  onClick={() => setExpanded(expanded === cs.id ? null : cs.id)}
                  className="w-full text-left p-6 lg:p-8 flex items-start justify-between gap-4"
                  style={{ cursor: "pointer" }}
                >
                  <div className="flex items-start gap-4">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 text-xl"
                      style={{ backgroundColor: `${cs.accentColor}18`, border: `1px solid ${cs.accentColor}30` }}
                    >
                      📊
                    </div>
                    <div>
                      <div className="flex items-center gap-3 mb-1 flex-wrap">
                        <span
                          className="text-xs font-semibold px-2 py-0.5 rounded-full"
                          style={{ backgroundColor: `${cs.accentColor}18`, color: cs.accentColor }}
                        >
                          {cs.tag}
                        </span>
                        <span className="text-xs text-gray-500">{cs.platform}</span>
                      </div>
                      <h2
                        className="text-xl"
                        style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, color: "#fff" }}
                      >
                        {cs.client}
                      </h2>
                      <p className="text-sm text-gray-500 mt-1">{cs.industry}</p>
                    </div>
                  </div>
                  <div className="text-gray-400 flex-shrink-0 mt-1">
                    {expanded === cs.id ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                  </div>
                </button>

                {/* Expanded Content */}
                {expanded === cs.id && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    transition={{ duration: 0.3 }}
                    className="px-6 lg:px-8 pb-8"
                  >
                    <div
                      className="pt-6"
                      style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}
                    >
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        {/* Left: Challenge + Strategy */}
                        <div>
                          <div className="mb-6">
                            <h3 className="text-sm font-bold text-orange-400 uppercase tracking-wider mb-3">The Challenge</h3>
                            <p className="text-gray-300 text-sm leading-relaxed">{cs.challenge}</p>
                          </div>

                          <div>
                            <h3 className="text-sm font-bold text-blue-400 uppercase tracking-wider mb-3">The Strategy</h3>
                            <ul className="space-y-2">
                              {cs.strategy.map((s, idx) => (
                                <li key={idx} className="flex items-start gap-2 text-sm text-gray-300">
                                  <div
                                    className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0"
                                    style={{ backgroundColor: cs.accentColor }}
                                  />
                                  {s}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>

                        {/* Right: Results */}
                        <div>
                          <h3 className="text-sm font-bold uppercase tracking-wider mb-3" style={{ color: cs.accentColor }}>Key Results</h3>
                          <div className="grid grid-cols-2 gap-3 mb-6">
                            {cs.results.map((r, idx) => (
                              <ResultCard key={idx} {...r} />
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Chart */}
                      <div className="mt-6">
                        <h3 className="text-sm font-bold text-green-400 uppercase tracking-wider mb-4">Performance Chart</h3>
                        <div
                          className="rounded-xl p-4"
                          style={{ backgroundColor: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.06)" }}
                        >
                          <ResponsiveContainer width="100%" height={200}>
                            {cs.chartType === "area" ? (
                              <AreaChart data={cs.chartData}>
                                <defs>
                                  <linearGradient id={`grad-${i}`} x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor={cs.accentColor} stopOpacity={0.3} />
                                    <stop offset="95%" stopColor={cs.accentColor} stopOpacity={0} />
                                  </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                                <XAxis dataKey="month" stroke="#6B7280" tick={{ fontSize: 11 }} />
                                <YAxis stroke="#6B7280" tick={{ fontSize: 11 }} />
                                <Tooltip content={<CustomTooltip />} />
                                <Area
                                  type="monotone"
                                  dataKey="revenue"
                                  name="Revenue ($)"
                                  stroke={cs.accentColor}
                                  fill={`url(#grad-${i})`}
                                  strokeWidth={2.5}
                                />
                              </AreaChart>
                            ) : cs.chartType === "bar" ? (
                              <BarChart data={cs.chartData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                                <XAxis dataKey="month" stroke="#6B7280" tick={{ fontSize: 11 }} />
                                <YAxis stroke="#6B7280" tick={{ fontSize: 11 }} />
                                <Tooltip content={<CustomTooltip />} />
                                <Bar dataKey="signups" name="Signups" fill={cs.accentColor} radius={[4, 4, 0, 0]} />
                                <Bar dataKey="cpa" name="CPA ($)" fill="#F97316" radius={[4, 4, 0, 0]} />
                              </BarChart>
                            ) : (
                              <LineChart data={cs.chartData}>
                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                                <XAxis dataKey="week" stroke="#6B7280" tick={{ fontSize: 11 }} />
                                <YAxis stroke="#6B7280" tick={{ fontSize: 11 }} />
                                <Tooltip content={<CustomTooltip />} />
                                <Line
                                  type="monotone"
                                  dataKey="conversions"
                                  name="Conversions"
                                  stroke={cs.accentColor}
                                  strokeWidth={2.5}
                                  dot={{ fill: cs.accentColor, r: 4 }}
                                />
                                <Line
                                  type="monotone"
                                  dataKey="spend"
                                  name="Spend ($)"
                                  stroke="#F97316"
                                  strokeWidth={2}
                                  strokeDasharray="5 5"
                                  dot={{ fill: "#F97316", r: 3 }}
                                />
                              </LineChart>
                            )}
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20" style={{ backgroundColor: "#050C18" }}>
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2
              className="text-3xl sm:text-4xl mb-5"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff" }}
            >
              Your Brand Could Be the Next Case Study
            </h2>
            <p className="text-gray-400 mb-8 text-sm leading-relaxed">
              Let's audit your ad accounts, find the leaks, and build a high-performance paid media engine for your business.
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-xl font-semibold text-sm transition-all duration-200 hover:scale-105"
              style={{
                background: "linear-gradient(135deg, #F97316, #EF4444)",
                color: "#fff",
                boxShadow: "0 8px 25px rgba(249,115,22,0.35)",
              }}
            >
              Get a Free Ad Account Audit
              <ArrowRight size={15} />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
