import { useState } from "react";
import { motion } from "motion/react";
import {
  Mail,
  MessageSquare,
  Phone,
  Linkedin,
  Facebook,
  Instagram,
  Calendar,
  Send,
  CheckCircle2,
  ExternalLink,
  Clock,
  Globe,
} from "lucide-react";

type FormData = {
  name: string;
  email: string;
  company: string;
  budget: string;
  platform: string;
  message: string;
};

const initialForm: FormData = {
  name: "",
  email: "",
  company: "",
  budget: "",
  platform: "",
  message: "",
};

export function Contact() {
  const [form, setForm] = useState<FormData>(initialForm);
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Partial<FormData>>({});

  const validate = () => {
    const newErrors: Partial<FormData> = {};
    if (!form.name.trim()) newErrors.name = "Name is required";
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      newErrors.email = "Valid email is required";
    if (!form.message.trim()) newErrors.message = "Message is required";
    return newErrors;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setLoading(true);
    setErrors({});
    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1800));
    setLoading(false);
    setSubmitted(true);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormData]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const inputStyle = (hasError?: string) => ({
    backgroundColor: "rgba(255,255,255,0.04)",
    border: `1px solid ${hasError ? "#EF4444" : "rgba(255,255,255,0.10)"}`,
    color: "#fff",
    outline: "none",
    borderRadius: "12px",
    padding: "12px 16px",
    width: "100%",
    fontSize: "14px",
    transition: "border-color 0.2s",
  });

  return (
    <div style={{ backgroundColor: "#0A0F1E" }}>
      {/* Header */}
      <section
        className="pt-28 pb-14 relative overflow-hidden"
        style={{ background: "radial-gradient(ellipse 80% 50% at 50% -10%, rgba(16,185,129,0.10) 0%, transparent 60%), #0A0F1E" }}
      >
        <div
          className="absolute inset-0 opacity-15"
          style={{
            backgroundImage: "linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)",
            backgroundSize: "60px 60px",
          }}
        />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#10B981" }}>Get In Touch</span>
            <h1
              className="mt-3 text-4xl sm:text-5xl lg:text-6xl"
              style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}
            >
              Let's Grow Your{" "}
              <span style={{ background: "linear-gradient(135deg, #10B981, #34D399)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Business Together
              </span>
            </h1>
            <p className="mt-5 text-gray-400 max-w-2xl mx-auto text-base leading-relaxed">
              Ready to transform your ad performance? Fill out the form below, or book a call directly. I'll personally review your business and get back to you within 24 hours.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="pb-24" style={{ backgroundColor: "#0A0F1E" }}>
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
            {/* Left: Contact Info */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="lg:col-span-2 space-y-6"
            >
              {/* Quick Info */}
              <div
                className="rounded-2xl p-6"
                style={{ backgroundColor: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <h3
                  className="text-base mb-4"
                  style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, color: "#fff" }}
                >
                  Contact Details
                </h3>
                <ul className="space-y-4">
                  <li className="flex items-center gap-3">
                    <div
                      className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: "rgba(16,185,129,0.12)", color: "#10B981" }}
                    >
                      <Mail size={16} />
                    </div>
                    <div>
                      <div className="text-xs text-gray-500">Email</div>
                      <div className="text-sm text-white">hello@spanishbaskey.com</div>
                    </div>
                  </li>
                  <li className="flex items-center gap-3">
                    <div
                      className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: "rgba(249,115,22,0.12)", color: "#F97316" }}
                    >
                      <Clock size={16} />
                    </div>
                    <div>
                      <div className="text-xs text-gray-500">Response Time</div>
                      <div className="text-sm text-white">Within 24 Hours</div>
                    </div>
                  </li>
                  <li className="flex items-center gap-3">
                    <div
                      className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: "rgba(59,130,246,0.12)", color: "#3B82F6" }}
                    >
                      <Globe size={16} />
                    </div>
                    <div>
                      <div className="text-xs text-gray-500">Location</div>
                      <div className="text-sm text-white">Available Worldwide (Remote)</div>
                    </div>
                  </li>
                </ul>
              </div>

              {/* Book a Call */}
              <div
                className="rounded-2xl p-6"
                style={{
                  background: "linear-gradient(135deg, rgba(16,185,129,0.10), rgba(59,130,246,0.06))",
                  border: "1px solid rgba(16,185,129,0.2)",
                }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <Calendar size={18} style={{ color: "#10B981" }} />
                  <h3
                    className="text-base"
                    style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, color: "#fff" }}
                  >
                    Book a Strategy Call
                  </h3>
                </div>
                <p className="text-gray-400 text-xs leading-relaxed mb-4">
                  Schedule a free 45-minute strategy call directly on my calendar. Choose a time that works for you.
                </p>
                <a
                  href="https://calendly.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 w-full justify-center px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200 hover:scale-105"
                  style={{
                    background: "linear-gradient(135deg, #10B981, #059669)",
                    color: "#fff",
                    boxShadow: "0 4px 14px rgba(16,185,129,0.3)",
                  }}
                >
                  <Calendar size={15} />
                  Schedule via Calendly
                  <ExternalLink size={13} />
                </a>
                <p className="text-xs text-gray-500 text-center mt-2">Opens in new tab · Powered by Calendly</p>
              </div>

              {/* Social Links */}
              <div
                className="rounded-2xl p-6"
                style={{ backgroundColor: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <h3
                  className="text-sm mb-4"
                  style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, color: "#fff" }}
                >
                  Connect on Social
                </h3>
                <div className="space-y-3">
                  {[
                    {
                      icon: <Linkedin size={16} />,
                      label: "LinkedIn",
                      handle: "@spanishbaskey",
                      href: "#",
                      color: "#3B82F6",
                    },
                    {
                      icon: <Facebook size={16} />,
                      label: "Facebook",
                      handle: "Spanish Baskey",
                      href: "#",
                      color: "#60A5FA",
                    },
                    {
                      icon: <Instagram size={16} />,
                      label: "TikTok / Instagram",
                      handle: "@spanishbaskey",
                      href: "#",
                      color: "#EC4899",
                    },
                  ].map((social, i) => (
                    <a
                      key={i}
                      href={social.href}
                      className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/5 transition-all duration-200 group"
                    >
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: `${social.color}15`, color: social.color }}
                      >
                        {social.icon}
                      </div>
                      <div>
                        <div className="text-xs text-gray-500">{social.label}</div>
                        <div className="text-sm text-gray-300 group-hover:text-white transition-colors">{social.handle}</div>
                      </div>
                      <ExternalLink size={13} className="ml-auto text-gray-600 group-hover:text-gray-400 transition-colors" />
                    </a>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Right: Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="lg:col-span-3"
            >
              <div
                className="rounded-2xl p-6 lg:p-8"
                style={{ backgroundColor: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                {submitted ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-12"
                  >
                    <div
                      className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-5"
                      style={{ backgroundColor: "rgba(16,185,129,0.15)", border: "2px solid rgba(16,185,129,0.3)" }}
                    >
                      <CheckCircle2 size={32} style={{ color: "#10B981" }} />
                    </div>
                    <h3
                      className="text-2xl mb-3"
                      style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, color: "#fff" }}
                    >
                      Message Received!
                    </h3>
                    <p className="text-gray-400 text-sm leading-relaxed max-w-xs mx-auto">
                      Thank you for reaching out! I'll personally review your details and respond within 24 hours.
                    </p>
                    <button
                      onClick={() => { setSubmitted(false); setForm(initialForm); }}
                      className="mt-6 px-5 py-2.5 rounded-xl text-sm font-medium text-gray-300 hover:text-white transition-colors"
                      style={{ border: "1px solid rgba(255,255,255,0.1)" }}
                    >
                      Send Another Message
                    </button>
                  </motion.div>
                ) : (
                  <>
                    <h2
                      className="text-xl mb-1"
                      style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, color: "#fff" }}
                    >
                      Send Me a Message
                    </h2>
                    <p className="text-gray-500 text-xs mb-6">
                      Fill in the details below and I'll be in touch within 24 hours.
                    </p>

                    <form onSubmit={handleSubmit} className="space-y-4">
                      {/* Name + Email */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1.5">
                            Your Name <span className="text-red-400">*</span>
                          </label>
                          <input
                            type="text"
                            name="name"
                            value={form.name}
                            onChange={handleChange}
                            placeholder="John Smith"
                            style={inputStyle(errors.name)}
                          />
                          {errors.name && <p className="text-xs text-red-400 mt-1">{errors.name}</p>}
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1.5">
                            Email Address <span className="text-red-400">*</span>
                          </label>
                          <input
                            type="email"
                            name="email"
                            value={form.email}
                            onChange={handleChange}
                            placeholder="john@company.com"
                            style={inputStyle(errors.email)}
                          />
                          {errors.email && <p className="text-xs text-red-400 mt-1">{errors.email}</p>}
                        </div>
                      </div>

                      {/* Company + Budget */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1.5">Company / Brand</label>
                          <input
                            type="text"
                            name="company"
                            value={form.company}
                            onChange={handleChange}
                            placeholder="Your Brand Name"
                            style={inputStyle()}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-400 mb-1.5">Monthly Ad Budget</label>
                          <select
                            name="budget"
                            value={form.budget}
                            onChange={handleChange}
                            style={{ ...inputStyle(), appearance: "none" }}
                          >
                            <option value="" style={{ backgroundColor: "#0D1B3E" }}>Select range...</option>
                            <option value="under-3k" style={{ backgroundColor: "#0D1B3E" }}>Under $3,000/mo</option>
                            <option value="3k-10k" style={{ backgroundColor: "#0D1B3E" }}>$3,000 – $10,000/mo</option>
                            <option value="10k-30k" style={{ backgroundColor: "#0D1B3E" }}>$10,000 – $30,000/mo</option>
                            <option value="30k-plus" style={{ backgroundColor: "#0D1B3E" }}>$30,000+/mo</option>
                          </select>
                        </div>
                      </div>

                      {/* Platform */}
                      <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1.5">Advertising Platform(s)</label>
                        <select
                          name="platform"
                          value={form.platform}
                          onChange={handleChange}
                          style={{ ...inputStyle(), appearance: "none" }}
                        >
                          <option value="" style={{ backgroundColor: "#0D1B3E" }}>Which platforms?</option>
                          <option value="facebook" style={{ backgroundColor: "#0D1B3E" }}>Facebook / Instagram Ads</option>
                          <option value="tiktok" style={{ backgroundColor: "#0D1B3E" }}>TikTok Ads</option>
                          <option value="both" style={{ backgroundColor: "#0D1B3E" }}>Both Platforms</option>
                          <option value="unsure" style={{ backgroundColor: "#0D1B3E" }}>Not Sure Yet</option>
                        </select>
                      </div>

                      {/* Message */}
                      <div>
                        <label className="block text-xs font-medium text-gray-400 mb-1.5">
                          Tell Me About Your Goals <span className="text-red-400">*</span>
                        </label>
                        <textarea
                          name="message"
                          value={form.message}
                          onChange={handleChange}
                          rows={5}
                          placeholder="Describe your business, current challenges, and what results you're hoping to achieve..."
                          style={{ ...inputStyle(errors.message), resize: "vertical" }}
                        />
                        {errors.message && <p className="text-xs text-red-400 mt-1">{errors.message}</p>}
                      </div>

                      {/* Privacy */}
                      <p className="text-xs text-gray-600">
                        By submitting, you agree that Spanish Baskey may contact you about your inquiry. Your information will never be shared with third parties.
                      </p>

                      {/* Submit */}
                      <button
                        type="submit"
                        disabled={loading}
                        className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm transition-all duration-200 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-70"
                        style={{
                          background: loading ? "rgba(16,185,129,0.5)" : "linear-gradient(135deg, #10B981, #059669)",
                          color: "#fff",
                          boxShadow: loading ? "none" : "0 6px 20px rgba(16,185,129,0.35)",
                          cursor: loading ? "not-allowed" : "pointer",
                        }}
                      >
                        {loading ? (
                          <>
                            <div
                              className="w-4 h-4 rounded-full border-2 border-white border-t-transparent animate-spin"
                            />
                            Sending...
                          </>
                        ) : (
                          <>
                            <Send size={15} />
                            Send Message
                          </>
                        )}
                      </button>
                    </form>
                  </>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Response Guarantee */}
      <section className="py-16" style={{ backgroundColor: "#050C18" }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center"
          >
            {[
              { icon: "⚡", title: "24-Hour Response", desc: "I personally respond to every inquiry within one business day." },
              { icon: "🎯", title: "Free Audit Included", desc: "Every initial consultation includes a complimentary ad account audit." },
              { icon: "🔒", title: "100% Confidential", desc: "Your business information and data stays completely private." },
            ].map((item, i) => (
              <div
                key={i}
                className="rounded-xl p-5"
                style={{ backgroundColor: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
              >
                <div className="text-3xl mb-3">{item.icon}</div>
                <h4 className="text-sm font-bold text-white mb-2" style={{ fontFamily: "'Syne', sans-serif" }}>{item.title}</h4>
                <p className="text-xs text-gray-500 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>
    </div>
  );
}
