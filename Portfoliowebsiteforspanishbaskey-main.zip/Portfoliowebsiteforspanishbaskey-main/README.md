
  # Portfolio website for Spanish Baskey

  This is a code bundle for Portfolio website for Spanish Baskey. The original project is available at https://www.figma.com/design/nu1GEWlFEKGmzsDh9DCA7a/Portfolio-website-for-Spanish-Baskey.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  